<?php

/* 
 * 九州云腾JWT解码 SSO登录 PHP Demo
 * JWT的解密我们这里使用第三方的解密库来实现，过程非常简单。
 * 集成方法：
 * 1. 添加FireBase的第三方JWT辅助库，链接：https://github.com/firebase/php-jwt，官方推荐使用composer require firebase/php-jwt来直接集成
 * 2. 将public key公钥pem文件放在可以访问到的位置，并读取出来
 * 3. 从url中读取传入的id_token参数
 * 4. 使用第一步中添加的JWT库，进行解密（如果加密和解密的服务器/主机的时间不合，可以通过修改leeway参数进行调整）
 * 5. 将解密出来的结果（class）转化成需要的格式并使用
 * 有任何问题请前往www.idsmangaer.com联系我们，我们会尽力帮助您开始使用！
 */

/* 使用composer 载入 php-jwt第三方库
 * 命令行 composer require firebase/php-jwt
 * 链接：https://github.com/firebase/php-jwt
 * 我们使用Firebase的这个第三方库来实现对jwt的解密
 */

// 在这里将JWT库引入
require 'vendor/autoload.php';
use \Firebase\JWT\JWT;

// 本地存储public key公钥的位置
$public_key_location = "LOCATION/TO/YOUR/PUBLIC-KEY/XXX.pem";

// 读取公钥信息
$public_key = file_get_contents($public_key_location);

// 从url的参数中读取token
if (!empty($_GET["id_token"])) {

	$jwt = $_GET["id_token"];

	try {

		/**
		 * You can add a leeway to account for when there is a clock skew times between
		 * the signing and verifying servers. It is recommended that this leeway should
		 * not be bigger than a few minutes.
		 *
		 * Source: http://self-issued.info/docs/draft-ietf-oauth-json-web-token.html#nbfDef
		 */
		// （可选）当服务器时间与本地时间不符时，可以通过这个leeway参数来调整容错
		JWT::$leeway = 60; // $leeway in seconds

		// 进行解密
		$decoded = JWT::decode($jwt, $public_key, array('RS256'));

		// 将解密的结果从class转化成array
		$decoded_array = (array) $decoded;

		// 打印出解密的结果，成功！
		print("解密结果<br>");
		foreach ($decoded_array as $key => $value) {
			print $key . ": " . $value . "<br>";
		}

	} catch(Exception $e) {
		print "错误：" . $e->getMessage();
	}	


} else {
	echo "错误：没有传入id_token参数";
}



?>